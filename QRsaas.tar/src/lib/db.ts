/**
 * 12-Factor App: Factor IV - Backing Services
 * Database connection through backing services manager
 */

import { backingServices } from '@/lib/backing-services';

// Export database client through backing services
export const db = backingServices.getDatabase();

// Export for backward compatibility
export default db;