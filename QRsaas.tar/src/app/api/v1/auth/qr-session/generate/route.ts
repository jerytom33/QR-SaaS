import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { v4 as uuidv4 } from 'uuid'
import { db } from '@/lib/db'

const generateQRSchema = z.object({
  deviceInfo: z.string().optional(),
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { deviceInfo } = generateQRSchema.parse(body)

    // Generate QR session
    const qrSessionId = uuidv4()
    const qrCodeData = JSON.stringify({
      sessionId: qrSessionId,
      timestamp: new Date().toISOString(),
      type: 'device-linking'
    })

    // Create default tenant for demo purposes
    let tenant = await db.tenant.findFirst({
      where: { slug: 'demo' }
    })

    if (!tenant) {
      tenant = await db.tenant.create({
        data: {
          name: 'Demo Organization',
          slug: 'demo',
          plan: 'FREE',
          maxUsers: 10
        }
      })
    }

    // Create QR session record
    const qrSession = await db.qRSession.create({
      data: {
        id: qrSessionId,
        status: 'PENDING',
        qrCodeData,
        expiresAt: new Date(Date.now() + 5 * 60 * 1000), // 5 minutes
        deviceInfo: deviceInfo || 'Unknown Device',
        tenantId: tenant.id
      }
    })

    return NextResponse.json({
      success: true,
      data: {
        qrSessionId: qrSession.id,
        qrCodeData: qrSession.qrCodeData,
        expiresAt: qrSession.expiresAt
      }
    })

  } catch (error) {
    console.error('QR generation error:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json({
        success: false,
        error: 'Invalid request data',
        details: error.errors
      }, { status: 400 })
    }

    return NextResponse.json({
      success: false,
      error: 'Failed to generate QR code'
    }, { status: 500 })
  }
}