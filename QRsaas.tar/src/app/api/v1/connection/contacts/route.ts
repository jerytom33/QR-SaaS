import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { db } from '@/lib/db'
import { v4 as uuidv4 } from 'uuid'

// API Key validation middleware
async function validateApiKey(request: NextRequest) {
  const apiKey = request.headers.get('x-api-key')
  
  if (!apiKey) {
    return { error: 'API key required', status: 401 }
  }

  // Find the API key in database
  const keyRecord = await db.apiKey.findFirst({
    where: {
      keyHash: Buffer.from(apiKey).toString('base64'),
      isActive: true
    },
    include: {
      tenant: true
    }
  })

  if (!keyRecord) {
    return { error: 'Invalid API key', status: 401 }
  }

  if (keyRecord.expiresAt && new Date() > keyRecord.expiresAt) {
    return { error: 'API key expired', status: 401 }
  }

  // Update last used timestamp
  await db.apiKey.update({
    where: { id: keyRecord.id },
    data: { lastUsedAt: new Date() }
  })

  return { tenantId: keyRecord.tenantId, keyRecord }
}

const createContactSchema = z.object({
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  email: z.string().email().optional(),
  phone: z.string().optional(),
  title: z.string().optional(),
  company: z.string().optional(),
  notes: z.string().optional(),
  tags: z.array(z.string()).optional(),
  customFields: z.record(z.any()).optional(),
})

const updateContactSchema = createContactSchema.partial()

// GET /api/v1/connection/contacts
export async function GET(request: NextRequest) {
  try {
    const validation = await validateApiKey(request)
    if (validation.error) {
      return NextResponse.json({
        success: false,
        error: validation.error
      }, { status: validation.status })
    }

    const { tenantId } = validation

    // Parse query parameters
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const search = searchParams.get('search') || ''
    const offset = (page - 1) * limit

    // Build where clause
    const where: any = {
      tenantId,
      ...(search && {
        OR: [
          { firstName: { contains: search } },
          { lastName: { contains: search } },
          { email: { contains: search } }
        ]
      })
    }

    // Get contacts with pagination
    const [contacts, total] = await Promise.all([
      db.contact.findMany({
        where,
        include: {
          company: true
        },
        orderBy: { createdAt: 'desc' },
        skip: offset,
        take: limit
      }),
      db.contact.count({ where })
    ])

    return NextResponse.json({
      success: true,
      data: {
        contacts,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit)
        }
      }
    })

  } catch (error) {
    console.error('Contacts GET error:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch contacts'
    }, { status: 500 })
  }
}

// POST /api/v1/connection/contacts
export async function POST(request: NextRequest) {
  try {
    const validation = await validateApiKey(request)
    if (validation.error) {
      return NextResponse.json({
        success: false,
        error: validation.error
      }, { status: validation.status })
    }

    const { tenantId } = validation
    const body = await request.json()
    const validatedData = createContactSchema.parse(body)

    // Check if contact with email already exists
    if (validatedData.email) {
      const existingContact = await db.contact.findFirst({
        where: {
          email: validatedData.email,
          tenantId
        }
      })

      if (existingContact) {
        return NextResponse.json({
          success: false,
          error: 'Contact with this email already exists'
        }, { status: 409 })
      }
    }

    // Create or find company
    let company = null
    if (validatedData.company) {
      company = await db.company.findFirst({
        where: {
          name: validatedData.company,
          tenantId
        }
      })

      if (!company) {
        company = await db.company.create({
          data: {
            name: validatedData.company,
            tenantId
          }
        })
      }
    }

    // Create contact
    const contact = await db.contact.create({
      data: {
        ...validatedData,
        tenantId,
        companyId: company?.id,
        tags: validatedData.tags ? JSON.stringify(validatedData.tags) : null,
        customFields: validatedData.customFields ? JSON.stringify(validatedData.customFields) : null
      },
      include: {
        company: true
      }
    })

    return NextResponse.json({
      success: true,
      data: contact
    }, { status: 201 })

  } catch (error) {
    console.error('Contact creation error:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json({
        success: false,
        error: 'Invalid request data',
        details: error.errors
      }, { status: 400 })
    }

    return NextResponse.json({
      success: false,
      error: 'Failed to create contact'
    }, { status: 500 })
  }
}

// PUT /api/v1/connection/contacts
export async function PUT(request: NextRequest) {
  try {
    const validation = await validateApiKey(request)
    if (validation.error) {
      return NextResponse.json({
        success: false,
        error: validation.error
      }, { status: validation.status })
    }

    const { tenantId } = validation
    const body = await request.json()
    const { id, ...updateData } = body

    if (!id) {
      return NextResponse.json({
        success: false,
        error: 'Contact ID is required'
      }, { status: 400 })
    }

    const validatedData = updateContactSchema.parse(updateData)

    // Check if contact exists and belongs to tenant
    const existingContact = await db.contact.findFirst({
      where: {
        id,
        tenantId
      }
    })

    if (!existingContact) {
      return NextResponse.json({
        success: false,
        error: 'Contact not found'
      }, { status: 404 })
    }

    // Handle company update
    let company = null
    if (validatedData.company) {
      company = await db.company.findFirst({
        where: {
          name: validatedData.company,
          tenantId
        }
      })

      if (!company) {
        company = await db.company.create({
          data: {
            name: validatedData.company,
            tenantId
          }
        })
      }
    }

    // Update contact
    const contact = await db.contact.update({
      where: { id },
      data: {
        ...validatedData,
        companyId: company?.id || existingContact.companyId,
        tags: validatedData.tags ? JSON.stringify(validatedData.tags) : existingContact.tags,
        customFields: validatedData.customFields ? JSON.stringify(validatedData.customFields) : existingContact.customFields
      },
      include: {
        company: true
      }
    })

    return NextResponse.json({
      success: true,
      data: contact
    })

  } catch (error) {
    console.error('Contact update error:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json({
        success: false,
        error: 'Invalid request data',
        details: error.errors
      }, { status: 400 })
    }

    return NextResponse.json({
      success: false,
      error: 'Failed to update contact'
    }, { status: 500 })
  }
}

// DELETE /api/v1/connection/contacts
export async function DELETE(request: NextRequest) {
  try {
    const validation = await validateApiKey(request)
    if (validation.error) {
      return NextResponse.json({
        success: false,
        error: validation.error
      }, { status: validation.status })
    }

    const { tenantId } = validation
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({
        success: false,
        error: 'Contact ID is required'
      }, { status: 400 })
    }

    // Check if contact exists and belongs to tenant
    const existingContact = await db.contact.findFirst({
      where: {
        id,
        tenantId
      }
    })

    if (!existingContact) {
      return NextResponse.json({
        success: false,
        error: 'Contact not found'
      }, { status: 404 })
    }

    // Delete contact
    await db.contact.delete({
      where: { id }
    })

    return NextResponse.json({
      success: true,
      message: 'Contact deleted successfully'
    })

  } catch (error) {
    console.error('Contact deletion error:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to delete contact'
    }, { status: 500 })
  }
}